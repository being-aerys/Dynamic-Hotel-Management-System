<?php

require('includes/application_top.php');

 if(!isset( $_GET["mode"] ) )
  {
    $mode = "form";
  }
else
 {
  $mode = $_GET["mode"];
 }

 $table="administrator";

?>

<!-- header_eof //-->

<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<title><?php echo TITLE; ?></title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">

 <style type="text/css">
BODY,TD {
	margin: 0px;
	font-size: 12px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
.MENU_TITLE {
	background-color: #BBC3D3;
	color: white;
	font-weight: bold;
	font-size: 12px;
	font-family: Verdana, Arial, Helvetica, sans-serif;
}
  .NAV {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 11px;
}
.msg
 {
   color:blue;
 }
  </style>

<script language="javascript">
 function field_new_username_check()
{
  if(document.admin_change_un_form.new_admin_un.value=="")
  {
    alert("You cannot have New Admin Username as blank");
    return false;

  }

}

function field_new_password_check()
{
  if(document.admin_change_pwd_form.new_admin_pwd.value=="")
  {
    alert("You cannot have New Admin Password as blank");
    return false;

  }
  if(document.admin_change_pwd_form.re_new_admin_pwd.value=="")
  {
    alert("You cannot have retype New Password Field as blank");
    return false;

  }
  
  if(document.admin_change_pwd_form.new_admin_pwd.value!=document.admin_change_pwd_form.re_new_admin_pwd.value)
  {
    alert("Passwords not matching");
    return false;
  }

}
</script>
</head>

<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0" bgcolor="#FFFFFF">

<!-- header //-->
<?php require(DIR_WS_INCLUDES . 'header.php'); ?>
<!-- header_eof //-->

<!-- body //-->
<table border="0" width="100%" cellspacing="2" cellpadding="2">
  <tr>
    <td width="<?php echo BOX_WIDTH; ?>" valign="top">
	 <table border="0" width="<?php echo BOX_WIDTH; ?>" cellspacing="1" cellpadding="1" class="columnLeft">
<!-- left_navigation //-->
<?php require(DIR_WS_INCLUDES . 'column_left.php'); ?>
<!-- left_navigation_eof //-->
    </table>
	</td>

    <td width="100%" valign="top">
    <table border="0" width="100%" cellspacing="0" cellpadding="2">
      <tr>
        <td>
        <table border="0" width="100%" cellspacing="0" cellpadding="0">
          <tr>
            <td class="pageHeading"><?php echo HEADER_TITLE_ADMIN_SECURITY; ?></td>
            <td class="pageHeading" align="right"></td>
          </tr>
        </table>
		</td>
      </tr>

      <tr>
        <td height="20"></td>
      </tr>
      <tr>
        <td align="center">
  <?php
  
  if($mode=="form")
  {
   ?>
   <table border="0" width="100%" >
<tr>
   <td>
  <form name="admin_change_un_form" action="<?php echo $_SERVER["PHP_SELF"]?>?mode=change_username" method ="POST" onsubmit="return field_new_username_check();">
         <table border="0" align='center' >
       <tr class="menu_title">
           <th colspan="2">
          <?
            if ( isset( $_GET["msg"] ) )
            {
                $msg = $_GET["msg"];
                if ( $msg == 'wu' )
                {
                    echo "<b class='msg'>Invalid Admin Username</b>";
                }
                else
               {
                   echo "<b class='msg'>Admin Username Changed</b>";
               }
            }
             else
               echo"<b>Change Admin Username Here</b>";

         ?>
      </th>
   </tr>

   <tr>
       <td > Old Admin Username : </td>
       <td> <input type="text" name="old_admin_un">
  </tr>

  <tr>
      <td > New Admin Username : </td>
      <td> <input type="text" name="new_admin_un">
  </tr>

  <tr>
    <th colspan="2"> <input type="submit" value="change.. " > </th>
  </tr>

</table>

</form>
</td>
</tr>
</table>


<table border="0" width="100%" >
<tr>
   <td>
<form name="admin_change_pwd_form" action="<?php echo $_SERVER["PHP_SELF"]?>?mode=change_password" method ="POST" onsubmit="return field_new_password_check();">
    <br><br>
        <table align ="center" border="0" >
      <tr class="menu_title">
       <th colspan="2" >
        <?
            if ( isset( $_GET["msg1"] ) )
            {
                $msg = $_GET["msg1"];
                if ( $msg == 'wp' )
                {
                    echo "<b class='msg'>Invalid Admin Password</b>";
                }
                else
                
               {
                   echo "<b class='msg'>Admin Password Changed</b>";
               }
            }
            else
               echo"<b>Change Admin Password Here</b>";

        ?>
     </th>
  </tr>
 <tr>
    <td > Old Admin Password : </td>
    <td> <input type="password" name="old_admin_pwd">
 </tr>

 <tr>
    <td > New Admin Password : </td>
    <td> <input type="password" name="new_admin_pwd">
</tr>

<tr>
    <td > Retype New Password : </td>
    <td> <input type="password" name="re_new_admin_pwd"
</tr>

 <tr>
    <th colspan="2"> <input type="submit" value="change.. " > </th>
 </tr>

</table>

</form>
</td>
</tr>
</table>
<?php
}//end if($mode=="form")
?>

<?php
if($mode=="change_username")
{
  $oldus=$_POST['old_admin_un'];
  $newus=$_POST['new_admin_un'];
  
  $query=mysql_query("select ID from $table where sName='$oldus' and sGUID<>'logged off'") or die ( mysql_error() );
  $row=mysql_fetch_array($query);
  
   if($row=="")
  {
     echo "<script>";
     echo "location.replace('".$_SERVER["PHP_SELF"]."?msg=wu')";
     echo "</script>";

  }
  else
  {
     $query=mysql_query("update $table set sName='$newus' where sGUID<>'logged off'") or die ( mysql_error() );
     echo "<script>";
     echo "location.replace('".$_SERVER["PHP_SELF"]."?msg=cu')";
     echo "</script>";
  }

}
?>
<?php
if($mode=="change_password")
{
  $oldpwd=$_POST['old_admin_pwd'];
  $newpwd=$_POST['new_admin_pwd'];
  
  $query=mysql_query("select ID from $table where sPassword=password('$oldpwd') and sGUID<>'logged off'") or die ( mysql_error() );
  $row=mysql_fetch_array($query);
  
   if($row=="")
  {
     echo "<script>";
     echo "location.replace('".$_SERVER["PHP_SELF"]."?msg1=wp')";
     echo "</script>";
  }
  else
  {
     $sql="update $table set sPassword=password('$newpwd') where sGUID<>'logged off'";
     $query=mysql_query($sql) or die ( mysql_error());
     echo "<script>";
     echo "location.replace('".$_SERVER["PHP_SELF"]."?msg1=cp')";
     echo "</script>";

  }
  
}
?>



        </td>
      </tr>
       </table>
   </td>
</tr>
</table>



 



<!-- footer //-->
<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
<!-- footer_eof //-->
<br>
</body>
</html>
<?php require(DIR_WS_INCLUDES . 'application_bottom.php'); ?>



