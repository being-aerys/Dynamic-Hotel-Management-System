<?php
// Include application configuration parameters
  require('includes/configure.php');
// include the database functions
  require(DIR_WS_FUNCTIONS . 'database.php');
// make a connection to the database... now
  tep_db_connect() or die('Unable to connect to database server!');
$psName=$_POST['psName'];
$psPassword=$_POST['psPassword'];
// Check if the information has been filled in
if(($psName == "") || ($psPassword == "")) {
// No login information
header('Location: ' . HTTPS_CATALOG_SERVER . DIR_WS_ADMIN . 'login.php?refer='.urlencode($psRefer));
} else {
// Authenticate user
$psName = addslashes($psName);
$psPassword = addslashes($psPassword);
$sQuery = "SELECT ID, MD5(UNIX_TIMESTAMP() + ID + RAND(UNIX_TIMESTAMP())), sGUID FROM administrator WHERE (sName = '$psName') AND (sPassword = password('$psPassword'))";
$hResult = mysql_query($sQuery);
if(mysql_affected_rows()) {
$aResult = mysql_fetch_row($hResult);
// Update the user record
$sQuery = "UPDATE administrator SET sGUID = '" . addslashes($aResult[1]) . "' WHERE ID = '" . addslashes($aResult[0]) . "'";
mysql_query($sQuery);
// Set the cookie and redirect
setcookie("session_id", $aResult[1]);
if(!$psRefer) $psRefer = HTTPS_CATALOG_SERVER . DIR_WS_ADMIN . 'index.php';
header('Location: ' . HTTPS_CATALOG_SERVER . DIR_WS_ADMIN . 'index.php');
} else {
// Not authenticated
header('Location: ' . HTTPS_CATALOG_SERVER . DIR_WS_ADMIN . 'login.php?refer='.urlencode($psRefer));
}
}
?>