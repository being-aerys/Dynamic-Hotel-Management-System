TodaysDate = new Date();
currentYear=TodaysDate.getFullYear();
var date_OK

function pd(m1, d1, y1) {
  date_OK = false;
  var days;
  with(document.forms.calendar) {
		if(date1.value == '' && date2.value == '') {
			date1.value = m1 + "/" + d1 +"/" + y1;
			day1.selectedIndex = parseInt(d1) -1;
			month1.selectedIndex = parseInt(m1) - 1;
			year1.selectedIndex = parseInt(y1) - currentYear;
		}	else if(date1.value != '' && date2.value =='') {
			date2.value = m1 + "/" + d1 +"/" + y1;
			day2.selectedIndex = parseInt(d1) -1;
			month2.selectedIndex = parseInt(m1) - 1;
			year2.selectedIndex = parseInt(y1) - currentYear;
			date_OK = true;
			var t1 = new Date(date1.value);
			var t2 = new Date(date2.value);
			var dt1 = new Date();
			var dt2 = new Date();
			var diff = new Date();
			dt1.setTime(t1.getTime());
			dt2.setTime(t2.getTime());
			diff.setTime((dt2.getTime() - dt1.getTime()) );
			timediff = diff.getTime();
			days = timediff / (1000 * 60 * 60 * 24 );
		}	else if (date1.value != '' && date2.value != '') {
			date1.value = y1 + "/" + m1 +"/" + d1;
			day1.selectedIndex = parseInt(d1) -1;
			month1.selectedIndex = parseInt(m1) - 1;
			year1.selectedIndex =  parseInt(y1) - currentYear;
			date2.value = '';
	  }

	  if ( days < 1 && date_OK ){
			date_OK = false;
			alert(" Your Start date is greater than your end date, Please choose again");
			date1.value = '';
			date2.value = '';
	  }	
	}
}
function sp(str,color) {
  document.forms.calendar.temp_price.value=str;
  if (str=='n/a') color='#999999';
  document.forms.calendar.temp_price.style.color=color;
}

function CompareDates(date1,date2) {
	var t1 = new Date(date1);
	var t2 = new Date(date2);
	var dt1 = new Date();
	var dt2 = new Date();
	var diff = new Date();
	dt1.setTime(t1.getTime());
	dt2.setTime(t2.getTime());
	diff.setTime((dt2.getTime() - dt1.getTime()) );
	timediff = diff.getTime();
	days = timediff / (1000 * 60 * 60 * 24 );
	return days<1;
}

function ValidateForm(form) {
  if (CompareDates(form.date1.value,form.date2.value)) {
    alert(" Your Start date is greater than your end date, Please choose again");
    return false;
  }
  
  /* 
  if (form.price.value=="") {
    alert('Please set the price');
    form.price.setFocus();
    return false;
  }
  */
  flag=false
  for(i=1;i<=4;i++) {
    if (form.price.options[i].checked) { flag=true; break;}
  }
  return flag;
}

function np(date) {
  alert('The date '+date+' has no price set. \\nPlease contact owner by the inquire for more information or choose again');
}
function na(date) {
  alert('The date '+date+' is not available, please choose again')
}