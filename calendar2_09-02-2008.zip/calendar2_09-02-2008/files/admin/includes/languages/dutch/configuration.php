<?php
/*
  $Id: configuration.php,v 1.7 2002/01/04 03:51:40 hpdl Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_CONFIGURATION_TITLE', 'Titel');
define('TABLE_HEADING_CONFIGURATION_VALUE', 'Value');
define('TABLE_HEADING_ACTION', 'Actie');

define('TEXT_INFO_EDIT_INTRO', 'Gelieve de nodige wijzigingen te maken');
define('TEXT_INFO_DATE_ADDED', 'Datum Toegevoegd:');
define('TEXT_INFO_LAST_MODIFIED', 'Laatst Gewijzigd:');
?>
