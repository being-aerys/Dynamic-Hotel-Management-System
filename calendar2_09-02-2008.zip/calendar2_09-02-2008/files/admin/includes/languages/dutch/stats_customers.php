<?php
/*
  $Id: stats_customers.php,v 1.6 2002/03/30 15:54:15 harley_vb Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Hoogte Totale Aankoopsom');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_CUSTOMERS', 'Klanten');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Totaal Aangekocht');
?>
