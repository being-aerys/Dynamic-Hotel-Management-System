<?php
/*
  $Id: countries.php,v 1.4 2002/01/12 17:02:18 hpdl Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Landen');

define('TABLE_HEADING_COUNTRY_NAME', 'Land');
define('TABLE_HEADING_COUNTRY_CODES', 'ISO Codes');
define('TABLE_HEADING_ACTION', 'Actie');

define('TEXT_INFO_EDIT_INTRO', 'Gelieve de nodige wijzigingen te maken');
define('TEXT_INFO_COUNTRY_NAME', 'Naam:');
define('TEXT_INFO_COUNTRY_CODE_2', 'ISO Code (2):');
define('TEXT_INFO_COUNTRY_CODE_3', 'ISO Code (3):');
define('TEXT_INFO_ADDRESS_FORMAT', 'Adres Formaat:');
define('TEXT_INFO_INSERT_INTRO', 'Gelieve het nieuwe land met bijbehorende data in te geven');
define('TEXT_INFO_DELETE_INTRO', 'Weet je zeker dat je dit land wil verwijderen?');
define('TEXT_INFO_HEADING_NEW_COUNTRY', 'Nieuw Land');
define('TEXT_INFO_HEADING_EDIT_COUNTRY', 'Wijzig Land');
define('TEXT_INFO_HEADING_DELETE_COUNTRY', 'Verwijder Land');
?>
