<?php
/*
  $Id: products_expected.php,v 1.7 2002/01/30 01:23:42 hpdl Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Artikelen Verwacht');

define('TABLE_HEADING_PRODUCTS', 'Artikelen');
define('TABLE_HEADING_DATE_EXPECTED', 'Verwacht op');
define('TABLE_HEADING_ACTION', 'Actie');

define('TEXT_INFO_DATE_EXPECTED', 'Verwacht Op:');
?>
