<?
/*
Dutch Text for The Exchange Project Administration Tool Preview Release 2.0
Last Update: 17/04/2001
Author(s): Ronald Smit (ronald.smit@hetnet.nl)
*/

define('TOP_BAR_TITLE', 'Betaalmodules');
define('HEADING_TITLE', 'Betaalmodules');

define('TABLE_HEADING_CONFIGURATION_TITLE', 'Filenaam');
define('TABLE_HEADING_CONFIGURATION_VALUE', 'Geinstalleerd');
define('TABLE_HEADING_ACTION', 'Installeer/Verwijder');

define('IMAGE_INSTALL_REMOVE', 'Klik om deze module te installeren/verwijderen');
?>
