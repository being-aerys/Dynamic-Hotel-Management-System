<?php
/*
  $Id: define_language.php,v 1.3 2002/01/05 12:19:50 hpdl Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Bepaal Taal');

define('TEXT_FILE_DOES_NOT_EXIST', 'Bestand bestaat niet.');

define('ERROR_FILE_NOT_WRITEABLE', 'Fout: Ik kan niet schrijven naar dit bestand, stel de juiste permissie\'s in voor: %s');
?>
