<?php
/*
  $Id: stats_products_viewed.php,v 1.5 2002/03/30 15:51:03 harley_vb Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Meest Bekeken Artikel');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_PRODUCTS', 'Artikelen');
define('TABLE_HEADING_VIEWED', 'Bekeken');
?>
