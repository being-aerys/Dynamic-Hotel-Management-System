<?php
/*
  $Id: whos_online.php,v 1.5 2002/03/30 15:48:55 harley_vb Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Wie Is Er Online');

define('TABLE_HEADING_ONLINE', 'Online');
define('TABLE_HEADING_CUSTOMER_ID', 'ID');
define('TABLE_HEADING_FULL_NAME', 'Volledige Naam');
define('TABLE_HEADING_IP_ADDRESS', 'IP Adres');
define('TABLE_HEADING_ENTRY_TIME', 'Tijdstip binnenkomst');
define('TABLE_HEADING_LAST_CLICK', 'Laatste Klik');
define('TABLE_HEADING_LAST_PAGE_URL', 'Laatste URL');
define('TABLE_HEADING_ACTION', 'Actie');
define('TABLE_HEADING_SHOPPING_CART', 'Winkelwagen Klant');
define('TEXT_SHOPPING_CART_SUBTOTAL', 'Subtotaal');
define('TEXT_NUMBER_OF_CUSTOMERS', 'Momenteel zijn er %s klanten online');
?>
