<?php
/*
  $Id: modules.php,v 1.6 2003/05/28 14:07:36 hpdl Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE_MODULES_PAYMENT', 'Betalingsmodule');
define('HEADING_TITLE_MODULES_SHIPPING', 'Verzendingsmodule');
define('HEADING_TITLE_MODULES_ORDER_TOTAL', 'Order Totaal Modules');

define('TABLE_HEADING_MODULES', 'Modules');
define('TABLE_HEADING_SORT_ORDER', 'Sort Orders');
define('TABLE_HEADING_ACTION', 'Actie');

define('TEXT_MODULE_DIRECTORY', 'Module Directory:');
?>
