<?php
/*
  $Id: packingslip.php,v 1.1 2002/06/11 17:41:55 dgw_ Exp $

  DUTCH TRANSLATION
  - V2.2 ms1: Author: Joost Billiet   Date: 06/18/2003   Mail: joost@jbpc.be
  - V2.2 ms2: Update: Martijn Loots   Date: 08/01/2003   Mail: oscommerce@cosix.com

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TABLE_HEADING_COMMENTS', 'Commentaar');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Model');
define('TABLE_HEADING_PRODUCTS', 'Artikelen');

define('ENTRY_SOLD_TO', 'Verkocht aan:');
define('ENTRY_SHIP_TO', 'Verzonden naar:');
define('ENTRY_PAYMENT_METHOD', 'Betaalwijze:');
?>
