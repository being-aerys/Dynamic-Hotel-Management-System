<?php
/*
  $Id: product_extra_fields.php,v 2.0 2004/11/09 15:07:21 ChBu Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Listing Extra Fields');
define('SUBHEADING_TITLE', 'Add a new field');

define('TABLE_HEADING_FIELDS', 'Listing Name');
define('TABLE_HEADING_ORDER', 'Sort Order');
define('TABLE_HEADING_LANGUAGE', 'Language');
define('TABLE_HEADING_STATUS', 'Status');

define('IMAGE_ADD_FIELD', 'Add new field');
define('IMAGE_UPDATE_FIELDS', 'Update fields');
define('IMAGE_REMOVE_FIELDS', 'Remove selected fields');

define ('TEXT_ALL_LANGUAGES', 'All');