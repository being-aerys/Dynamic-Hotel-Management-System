<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
	Includes Contribution:
  Access with Level Account (v. 2.2a) for the Admin Area of osCommerce (MS2)

	This page may be deleted if disabling the above contribution
*/

define('HEADING_TITLE', 'Access Denied');
define('NAVBAR_TITLE', 'No Right Permission Access');
define('TEXT_MAIN', '&nbsp;Please contact your <b>Web Administrator</b> to request <br>&nbsp;more access or if you found any problem.<br>&nbsp;');
define('TEXT_BACK', 'back');
?>