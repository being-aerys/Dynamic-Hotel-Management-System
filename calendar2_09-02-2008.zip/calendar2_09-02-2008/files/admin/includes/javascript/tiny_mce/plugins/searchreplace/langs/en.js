// UK lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Find',
searchreplace_searchnext_desc : 'Find again',
searchreplace_replace_desc : 'Find/Replace',
searchreplace_notfound : 'The search has been completed. The search string could not be found.',
searchreplace_search_title : 'Find',
searchreplace_replace_title : 'Find/Replace',
searchreplace_allreplaced : 'All occurrences of the search string were replaced.',
searchreplace_findwhat : 'Find what',
searchreplace_replacewith : 'Replace with',
searchreplace_direction : 'Direction',
searchreplace_up : 'Up',
searchreplace_down : 'Down',
searchreplace_case : 'Match case',
searchreplace_findnext : 'Find&nbsp;next',
searchreplace_replace : 'Replace',
searchreplace_replaceall : 'Replace&nbsp;all',
searchreplace_cancel : 'Cancel'
});
