<?php

$mailheader="Your Booking request for Villa X";

$siteulr=HTTP_SERVER.DIR_WS_CATALOG;

$db_host=DB_SERVER;

$db_user=DB_SERVER_USERNAME;

$db_pass=DB_SERVER_PASSWORD;

$db_database=DB_DATABASE;



function connect_db()

{

  global $db_host,$db_user,$db_pass,$db_database;



  mysql_connect($db_host, $db_user, $db_pass) || die("Error: ".mysql_error());

  mysql_select_db($db_database) || die("Error: ".mysql_error());

}



if ($gpc=get_magic_quotes_gpc())

{

  for (reset ($_POST); list ($k, $v) = each ($_POST);)

  {

    if(!is_array($v)) $_POST[$k] = stripslashes ($v);

  }

  for (reset ($HTTP_GET_VARS); list ($k, $v) = each ($_GET);)

  {

    if(!is_array($v)) $_GET[$k] = stripslashes ($v);

  }

}

set_magic_quotes_runtime(0);



?>
