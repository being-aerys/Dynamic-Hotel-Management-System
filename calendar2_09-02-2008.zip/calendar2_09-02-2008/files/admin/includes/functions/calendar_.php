<?php
function date_corection($selected_dates, $product_id)
{
	$ex_dates=array();

	$ex_dates_query = tep_db_query("select * from " . TABLE_PRODUCTS_CALENDAR . " where product_id = '" . $product_id . "'");

	$i = 0;
	while($rec = mysql_fetch_array($ex_dates_query)) {
		$ex_dates[$i]['products_calendar_id'] = $rec['products_calendar_id'];
		$ex_dates[$i]['product_id'] = $rec['product_id'];
		$ex_dates[$i]['start_date'] = $rec['start_date'];
		$ex_dates[$i]['end_date'] = $rec['end_date'];
		$ex_dates[$i]['price'] = $rec['price'];
		$ex_dates[$i]['status'] = $rec['status'];

		$i++;
	}
	if(empty($ex_dates))
	{
		if($selected_dates['status'] == 1)
		{
			date_insert($selected_dates);
		}
		return;
	}

	$date_action = false;

	for($i = 0; $i <= count($ex_dates); $i++)
	{
		if($selected_dates['status'] == 1)
		{
			if(($selected_dates['start_date'] < $ex_dates[$i]['start_date'])
			AND (($selected_dates['end_date'] == $ex_dates[$i]['start_date']) OR ($selected_dates['end_date'] > $ex_dates[$i]['start_date']))
			AND ($selected_dates['end_date'] < $ex_dates[$i]['end_date']))
			{
				$date_action = true;
				if($selected_dates['price'] == $ex_dates[$i]['price'])
				{
					$start_date = $selected_dates['start_date'];
					$end_date = $ex_dates[$i]['end_date'];

					date_delete($ex_dates[$i]['products_calendar_id']);
					$ex_dates[$i]['products_calendar_id'] = NULL;

					$ex_dates[$i]['start_date'] = $start_date;
					$ex_dates[$i]['end_date'] = $end_date;
					date_insert($ex_dates[$i]);
				}else{
					$start_date1 = $selected_dates['start_date'];
					$end_date1 = $selected_dates['end_date'];

					$start_date2 = date_tomorrow($selected_dates['end_date']);
					$end_date2 = $ex_dates[$i]['end_date'];

					date_delete($ex_dates[$i]['products_calendar_id']);
					$ex_dates[$i]['products_calendar_id'] = NULL;

					$selected_dates['start_date'] = $start_date1;
					$selected_dates['end_date'] = $end_date1;
					date_insert($selected_dates); //price2

					$ex_dates[$i]['start_date'] = $start_date2;
					$ex_dates[$i]['end_date'] = $end_date2;
					date_insert($ex_dates[$i]); //price1
				}
			}
			//-------------------------------------------
			if(($selected_dates['start_date'] > $ex_dates[$i]['start_date'])
			AND ($selected_dates['start_date'] < $ex_dates[$i]['end_date'])
			AND ($selected_dates['end_date'] > $ex_dates[$i]['start_date'])
			AND ($selected_dates['end_date'] < $ex_dates[$i]['end_date']))
			{
				$date_action = true;
				if($selected_dates['price'] == $ex_dates[$i]['price'])
				{
				}else{
					$start_date1 = $ex_dates[$i]['start_date'];
					$end_date1 = date_yesterday($selected_dates['start_date']);

					$start_date2 = $selected_dates['start_date'];
					$end_date2 = $selected_dates['end_date'];

					$start_date3 = date_tomorrow($selected_dates['end_date']);
					$end_date3 = $ex_dates[$i]['end_date'];

					date_delete($ex_dates[$i]['products_calendar_id']);
					$ex_dates[$i]['products_calendar_id'] = NULL;

					$ex_dates[$i]['start_date'] = $start_date1;
					$ex_dates[$i]['end_date'] = $end_date1;
					date_insert($ex_dates[$i]); //price1

					$selected_dates['start_date'] = $start_date2;
					$selected_dates['end_date'] = $end_date2;
					date_insert($selected_dates); //price2

					$ex_dates[$i]['start_date'] = $start_date3;
					$ex_dates[$i]['end_date'] = $end_date3;
					date_insert($ex_dates[$i]); //price1
				}
			}
			//-------------------------------------------
			if((($selected_dates['start_date'] <= $ex_dates[$i]['start_date'])
			AND ($selected_dates['end_date'] >= $ex_dates[$i]['end_date'])))
			{
				date_delete($ex_dates[$i]['products_calendar_id']);
				(!$date_action)?date_insert($selected_dates):''; //price2
				$date_action = true;
			}
			//-------------------------------------------
			if(($selected_dates['start_date'] > $ex_dates[$i]['start_date'])
			AND (($selected_dates['start_date'] < $ex_dates[$i]['end_date']) OR ($selected_dates['start_date'] == $ex_dates[$i]['end_date']))
			AND ($selected_dates['end_date'] > $ex_dates[$i]['end_date']))
			{
				if($selected_dates['price'] == $ex_dates[$i]['price'])
				{
					$start_date = $ex_dates[$i]['start_date'];
					$end_date = $selected_dates['end_date'];

					date_delete($ex_dates[$i]['products_calendar_id']);
					$ex_dates[$i]['products_calendar_id'] = NULL;

					$ex_dates[$i]['start_date'] = $start_date;
					$ex_dates[$i]['end_date'] = $end_date;
					date_insert($ex_dates[$i]); //price1
				}else{
					$start_date1 = $ex_dates[$i]['start_date'];
					$end_date1 = date_yesterday($selected_dates['start_date']);

					$start_date2 = $selected_dates['start_date'];
					$end_date2 = $selected_dates['end_date'];

					date_delete($ex_dates[$i]['products_calendar_id']);
					$ex_dates[$i]['products_calendar_id'] = NULL;

					$ex_dates[$i]['start_date'] = $start_date1;
					$ex_dates[$i]['end_date'] = $end_date1;
					date_insert($selected_dates); //price1

					$selected_dates['start_date'] = $start_date2;
					$selected_dates['end_date'] = $end_date2;
					date_insert($ex_dates[$i]); //price1
				}
				$date_action = true;
			}
		}
		/**/   elseif($selected_dates['status'] == 2)
		{

			if(($selected_dates['start_date'] < $ex_dates[$i]['start_date'])
			AND (($selected_dates['end_date'] == $ex_dates[$i]['start_date']) OR ($selected_dates['end_date'] > $ex_dates[$i]['start_date']))
			AND ($selected_dates['end_date'] < $ex_dates[$i]['end_date']))
			{
				$date_action = true;
				$start_date = date_tomorrow($selected_dates['end_date']);
				$end_date = $ex_dates[$i]['end_date'];

				date_delete($ex_dates[$i]['products_calendar_id']);
				$ex_dates[$i]['products_calendar_id'] = NULL;

				$ex_dates[$i]['start_date'] = $start_date;
				$ex_dates[$i]['end_date'] = $end_date;

				date_insert($ex_dates[$i]);
			}
			//-------------------------------------------
			if(($ex_dates[$i]['start_date'] < $selected_dates['start_date'])
			AND ($selected_dates['start_date'] < $ex_dates[$i]['end_date'])
			AND ($selected_dates['end_date'] > $ex_dates[$i]['start_date'])
			AND ($selected_dates['end_date'] < $ex_dates[$i]['end_date']))
			{
				$date_action = true;
				$start_date1 = $ex_dates[$i]['start_date'];
				$end_date1 = date_yesterday($selected_dates['start_date']);

				$start_date2 = date_tomorrow($selected_dates['end_date']);
				$end_date2 = $ex_dates[$i]['end_date'];

				date_delete($ex_dates[$i]['products_calendar_id']);
				$ex_dates[$i]['products_calendar_id'] = NULL;

				$ex_dates[$i]['start_date'] = $start_date1;
				$ex_dates[$i]['end_date'] = $end_date1;
				date_insert($ex_dates[$i]); //price1

				$ex_dates[$i]['start_date'] = $start_date2;
				$ex_dates[$i]['end_date'] = $end_date2;
				date_insert($ex_dates[$i]); //price1
			}
			//-------------------------------------------
			if((($selected_dates['start_date'] <= $ex_dates[$i]['start_date'])
			AND ($selected_dates['end_date'] >= $ex_dates[$i]['end_date'])))
			{
				$date_action = true;
				date_delete($ex_dates[$i]['products_calendar_id']);
			}
			//-------------------------------------------
			if(($selected_dates['start_date'] > $ex_dates[$i]['start_date'])
			AND (($selected_dates['start_date'] < $ex_dates[$i]['end_date']) OR ($selected_dates['start_date'] == $ex_dates[$i]['end_date']))
			AND ($selected_dates['end_date'] > $ex_dates[$i]['end_date']))
			{
				$start_date = $ex_dates[$i]['start_date'];
				$end_date = date_yesterday($selected_dates['start_date']);

				date_delete($ex_dates[$i]['products_calendar_id']);
				$ex_dates[$i]['products_calendar_id'] = NULL;

				$ex_dates[$i]['start_date'] = $start_date;
				$ex_dates[$i]['end_date'] = $end_date;

				(!$date_action)?date_insert($ex_dates[$i]):'';
				$date_action = true;
			}
		}
		//-------------------------------------------
	}

	if(!$date_action)
	{
		if($selected_dates['status'] == 1)
		{
			date_insert($selected_dates);
		}
	}
}

function date_delete($product_calendar_id)
{
	tep_db_query("delete from " . TABLE_PRODUCTS_CALENDAR . " where products_calendar_id = '" . (int)$product_calendar_id . "'");
}

function date_insert($sql_data)
{
	tep_db_perform(TABLE_PRODUCTS_CALENDAR, $sql_data);
}

function date_tomorrow($date)
{
	$date = explode('-', $date);
	return date("Y-m-d",mktime(0,0,0,$date[1],$date[2],$date[0]) + 86400);
}

function date_yesterday($date)
{
	$date = explode('-', $date);
	return date("Y-m-d",mktime(0,0,0,$date[1],$date[2],$date[0]) - 86400);
}
?>