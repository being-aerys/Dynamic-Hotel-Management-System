<?php
function date_corection($selected_dates, $product_id) {

	//exit('<pre>'.print_r($selected_dates));
	if ($selected_dates['product_id']>0) {
		$ex_dates=array();
		$av_products_calendar_id_ar = array();
		tep_db_query("delete from " . TABLE_PRODUCTS_CALENDAR . " where product_id = '" . $product_id . "' and (start_date >='".$selected_dates['start_date'].'\' and end_date<= \''.$selected_dates['end_date'].'\')');

		// date between select
		/*$ex_dates_sql = "select products_calendar_id from " . TABLE_PRODUCTS_CALENDAR . " where product_id = '" . $product_id . "' and (start_date >='".$selected_dates['start_date'].'\' and end_date<= \''.$selected_dates['end_date'].'\')';
		$ex_dates_query = tep_db_query($ex_dates_sql);
		while($rec = mysql_fetch_array($ex_dates_query)) {
		$av_products_calendar_id_ar[] = $rec['products_calendar_id'];
		} */
		// date less select
		$ex_dates_sql = "select * from " . TABLE_PRODUCTS_CALENDAR . " where product_id = '" . $product_id . "' and (start_date <'".$selected_dates['start_date'].'\') order by start_date desc';
		//echo $ex_dates_sql.'<br>';
		$ex_dates_query = tep_db_query($ex_dates_sql);
		$rec = mysql_fetch_array($ex_dates_query);
		//unset($left_date);
		//unset($right_date);
		if ($rec) {
			$av_products_calendar_id_ar[] = $rec['products_calendar_id'];
			$left_ar['products_calendar_id'] = $rec['products_calendar_id'];
			$left_ar['start_date'] = $rec['start_date'];
			$left_ar['end_date'] = $rec['end_date'];
			$left_ar['status'] = $rec['status'];
			$left_ar['price'] = $rec['price'];

			$left_date['product_id'] = $selected_dates['product_id'];
			$left_date['end_date'] = date_yesterday($selected_dates['start_date']);
			if ($rec['status'] <> $selected_dates['status']) {
				$left_date['status'] = $rec['status'];
				$left_date['start_date'] = $rec['start_date'];
			}
			else {
				$left_date['start_date'] = date_tomorrow($rec['end_date']);
				if ($rec['status'] == 1) $left_date['status'] = 2; else $left_date['status'] = 1;
			}
			if ($left_date['status'] == 1)
			$left_date['price'] = $rec['price'];
			//date_delete($rec['products_calendar_id']);
			//date_insert($left_date);
		}
		// date more select
		$ex_dates_sql = "select * from " . TABLE_PRODUCTS_CALENDAR . " where product_id = '" . $product_id . "' and (end_date >'".$selected_dates['end_date'].'\') order by end_date asc';
		//echo $ex_dates_sql.'<br>';
		$ex_dates_query = tep_db_query($ex_dates_sql);
		$rec = mysql_fetch_array($ex_dates_query);
		if ($rec) {
			$av_products_calendar_id_ar[] = $rec['products_calendar_id'];
			$right_ar['products_calendar_id'] = $rec['products_calendar_id'];
			$right_ar['start_date'] = $rec['start_date'];
			$right_ar['end_date'] = $rec['end_date'];
			$right_ar['status'] = $rec['status'];
			//$right_ar['price'] = $rec['price'];

			$right_date['product_id'] = $selected_dates['product_id'];
			$right_date['start_date'] = date_tomorrow($selected_dates['end_date']);
			//$right_date['end_date'] = $rec['end_date'];
			//$right_date['price'] = $rec['price'];
			//$right_date['status'] = $rec['status'];
			
			if ($rec['status'] <> $selected_dates['status']) {
				$right_date['status'] = $rec['status'];
				$right_date['end_date'] = $rec['end_date'];
			}
			else {
				$right_date['end_date'] = date_yesterday($rec['start_date']);
				if ($rec['status'] == 1) $right_date['status'] = 2; else $right_date['status'] = 1;
			}
			if ($right_date['status'] == 1)
			$right_date['price'] = $rec['price'];
			
			//date_delete($rec['products_calendar_id']);
			//date_insert($right_date);
		}

		//echo "delete from " . TABLE_PRODUCTS_CALENDAR . " where product_id = '" . $product_id . "' and (start_date >='".$selected_dates['start_date'].'\' and end_date<= \''.$selected_dates['end_date'].'\')';

		//exit('<pre>'.print_r($av_products_calendar_id_ar,true));

		date_insert($selected_dates);
		/*echo '<pre>';
		print_r($left_ar);
		print_r($selected_dates);
		print_r($right_ar); */
		//exit();
		if (sizeof($left_date)>0)
		if ($left_ar['status']<>$selected_dates['status'])
		date_delete($left_ar['products_calendar_id']);
		
		if (sizeof($right_date)>0)
		if ($right_ar['status']<>$selected_dates['status'])
		date_delete($right_ar['products_calendar_id']);
		
		
		if (sizeof($left_date)>0) date_insert($left_date);
		if (sizeof($right_date)>0) date_insert($right_date);
		/*if ($left_ar['status']<>$selected_dates['status'])
		date_delete($left_ar['products_calendar_id']);
		if ($right_ar['status']<>$selected_dates['status'])
		date_delete($right_ar['products_calendar_id']); */
	}
	/*echo '<pre>';
	print_r($left_date);
	print_r($right_date);
	print_r($selected_dates);*/
	//exit();


	//print_r($av_products_calendar_id_ar);
	//echo count($av_products_calendar_id_ar).'<br>';
	//exit((count($av_products_calendar_id_ar)>0));
	/*$ex_dates_sql = "select * from " . TABLE_PRODUCTS_CALENDAR . " where product_id = '" . $product_id .'\' '. ((sizeof($av_products_calendar_id_ar)>0) ? ' and (products_calendar_id in ('.implode(',',$av_products_calendar_id_ar).'))':'');
	//	exit($ex_dates_sql);
	$ex_dates_query = tep_db_query($ex_dates_sql);

	$i = 0;
	while($rec = mysql_fetch_array($ex_dates_query)) {
	$ex_dates[$i]['products_calendar_id'] = $rec['products_calendar_id'];
	$ex_dates[$i]['product_id'] = $rec['product_id'];
	$ex_dates[$i]['start_date'] = $rec['start_date'];
	$ex_dates[$i]['end_date'] = $rec['end_date'];
	$ex_dates[$i]['price'] = $rec['price'];
	$ex_dates[$i]['status'] = $rec['status'];

	$i++;
	} */

	//exit('<pre>'.print_r($ex_dates,true));

	/*if(empty($ex_dates))
	{
	if($selected_dates['status'] == 1)
	{
	date_insert($selected_dates);
	}
	return;
	} */

	/*$date_action = false;

	for($i = 0; $i <= count($ex_dates); $i++)
	{
	if($selected_dates['status'] == 1)
	{
	if(($selected_dates['start_date'] < $ex_dates[$i]['start_date'])
	AND (($selected_dates['end_date'] == $ex_dates[$i]['start_date']) OR ($selected_dates['end_date'] > $ex_dates[$i]['start_date']))
	AND ($selected_dates['end_date'] < $ex_dates[$i]['end_date']))
	{
	$date_action = true;
	if($selected_dates['price'] == $ex_dates[$i]['price'])
	{
	$start_date = $selected_dates['start_date'];
	$end_date = $ex_dates[$i]['end_date'];

	date_delete($ex_dates[$i]['products_calendar_id']);
	$ex_dates[$i]['products_calendar_id'] = NULL;

	$ex_dates[$i]['start_date'] = $start_date;
	$ex_dates[$i]['end_date'] = $end_date;
	date_insert($ex_dates[$i]);
	}else{
	$start_date1 = $selected_dates['start_date'];
	$end_date1 = $selected_dates['end_date'];

	$start_date2 = date_tomorrow($selected_dates['end_date']);
	$end_date2 = $ex_dates[$i]['end_date'];

	date_delete($ex_dates[$i]['products_calendar_id']);
	$ex_dates[$i]['products_calendar_id'] = NULL;

	$selected_dates['start_date'] = $start_date1;
	$selected_dates['end_date'] = $end_date1;
	date_insert($selected_dates); //price2

	$ex_dates[$i]['start_date'] = $start_date2;
	$ex_dates[$i]['end_date'] = $end_date2;
	date_insert($ex_dates[$i]); //price1
	}
	}
	//-------------------------------------------
	if(($selected_dates['start_date'] > $ex_dates[$i]['start_date'])
	AND ($selected_dates['start_date'] < $ex_dates[$i]['end_date'])
	AND ($selected_dates['end_date'] > $ex_dates[$i]['start_date'])
	AND ($selected_dates['end_date'] < $ex_dates[$i]['end_date']))
	{
	$date_action = true;
	if($selected_dates['price'] == $ex_dates[$i]['price'])
	{
	}else{
	$start_date1 = $ex_dates[$i]['start_date'];
	$end_date1 = date_yesterday($selected_dates['start_date']);

	$start_date2 = $selected_dates['start_date'];
	$end_date2 = $selected_dates['end_date'];

	$start_date3 = date_tomorrow($selected_dates['end_date']);
	$end_date3 = $ex_dates[$i]['end_date'];

	date_delete($ex_dates[$i]['products_calendar_id']);
	$ex_dates[$i]['products_calendar_id'] = NULL;

	$ex_dates[$i]['start_date'] = $start_date1;
	$ex_dates[$i]['end_date'] = $end_date1;
	date_insert($ex_dates[$i]); //price1

	$selected_dates['start_date'] = $start_date2;
	$selected_dates['end_date'] = $end_date2;
	date_insert($selected_dates); //price2

	$ex_dates[$i]['start_date'] = $start_date3;
	$ex_dates[$i]['end_date'] = $end_date3;
	date_insert($ex_dates[$i]); //price1
	}
	}
	//-------------------------------------------
	if((($selected_dates['start_date'] == $ex_dates[$i]['start_date'])
	AND ($selected_dates['end_date'] == $ex_dates[$i]['end_date'])) OR (($selected_dates['start_date'] < $ex_dates[$i]['start_date'])
	AND ($selected_dates['end_date'] > $ex_dates[$i]['end_date'])))
	{
	$date_action = true;
	date_delete($ex_dates[$i]['products_calendar_id']);
	date_insert($selected_dates); //price2
	}
	//-------------------------------------------
	if(($selected_dates['start_date'] > $ex_dates[$i]['start_date'])
	AND (($selected_dates['start_date'] < $ex_dates[$i]['end_date']) OR ($selected_dates['start_date'] == $ex_dates[$i]['end_date']))
	AND ($selected_dates['end_date'] > $ex_dates[$i]['end_date']))
	{
	$date_action = true;
	if($selected_dates['price'] == $ex_dates[$i]['price'])
	{
	$start_date = $ex_dates[$i]['start_date'];
	$end_date = $selected_dates['end_date'];

	date_delete($ex_dates[$i]['products_calendar_id']);
	$ex_dates[$i]['products_calendar_id'] = NULL;

	$ex_dates[$i]['start_date'] = $start_date;
	$ex_dates[$i]['end_date'] = $end_date;
	date_insert($ex_dates[$i]); //price1
	}else{
	$start_date1 = $ex_dates[$i]['start_date'];
	$end_date1 = date_yesterday($selected_dates['start_date']);

	$start_date2 = $selected_dates['start_date'];
	$end_date2 = $selected_dates['end_date'];

	date_delete($ex_dates[$i]['products_calendar_id']);
	$ex_dates[$i]['products_calendar_id'] = NULL;

	$ex_dates[$i]['start_date'] = $start_date1;
	$ex_dates[$i]['end_date'] = $end_date1;
	date_insert($selected_dates); //price1

	$selected_dates['start_date'] = $start_date2;
	$selected_dates['end_date'] = $end_date2;
	date_insert($ex_dates[$i]); //price1
	}
	}
	}
	elseif($selected_dates['status'] == 2)
	{
	if(($selected_dates['start_date'] < $ex_dates[$i]['start_date'])
	AND (($selected_dates['end_date'] == $ex_dates[$i]['start_date']) OR ($selected_dates['end_date'] > $ex_dates[$i]['start_date']))
	AND ($selected_dates['end_date'] < $ex_dates[$i]['end_date']))
	{
	$date_action = true;
	$start_date = date_tomorrow($selected_dates['end_date']);
	$end_date = $ex_dates[$i]['end_date'];

	date_delete($ex_dates[$i]['products_calendar_id']);
	$ex_dates[$i]['products_calendar_id'] = NULL;

	$ex_dates[$i]['start_date'] = $start_date;
	$ex_dates[$i]['end_date'] = $end_date;

	date_insert($ex_dates[$i]);
	}
	//-------------------------------------------
	if(($ex_dates[$i]['start_date'] < $selected_dates['start_date'])
	AND ($selected_dates['start_date'] < $ex_dates[$i]['end_date'])
	AND ($selected_dates['end_date'] > $ex_dates[$i]['start_date'])
	AND ($selected_dates['end_date'] < $ex_dates[$i]['end_date']))
	{
	$date_action = true;
	$start_date1 = $ex_dates[($i-1)]['start_date'];
	$end_date1 = date_yesterday($selected_dates['start_date']);

	$start_date2 = date_tomorrow($selected_dates['end_date']);
	$end_date2 = $ex_dates[$i]['end_date'];

	date_delete($ex_dates[$i]['products_calendar_id']);
	$ex_dates[$i]['products_calendar_id'] = NULL;

	$ex_dates[$i]['start_date'] = $start_date1;
	$ex_dates[$i]['end_date'] = $end_date1;
	date_insert($selected_dates); //price1

	$ex_dates[$i]['start_date'] = $start_date2;
	$ex_dates[$i]['end_date'] = $end_date2;
	date_insert($ex_dates[$i]); //price1

	}
	//-------------------------------------------
	if((($selected_dates['start_date'] == $ex_dates[$i]['start_date'])
	AND ($selected_dates['end_date'] == $ex_dates[$i]['end_date'])) OR (($selected_dates['start_date'] < $ex_dates[$i]['start_date'])
	AND ($selected_dates['end_date'] > $ex_dates[$i]['end_date'])))
	{
	$date_action = true;
	date_delete($ex_dates[$i]['products_calendar_id']);
	}
	//-------------------------------------------
	if(($selected_dates['start_date'] > $ex_dates[$i]['start_date'])
	AND (($selected_dates['start_date'] < $ex_dates[$i]['end_date']) OR ($selected_dates['start_date'] == $ex_dates[$i]['end_date']))
	AND ($selected_dates['end_date'] > $ex_dates[$i]['end_date']))
	{
	$start_date = $ex_dates[$i]['start_date'];
	$end_date = date_yesterday($selected_dates['start_date']);

	date_delete($ex_dates[$i]['products_calendar_id']);
	$ex_dates[$i]['products_calendar_id'] = NULL;

	$ex_dates[$i]['start_date'] = $start_date;
	$ex_dates[$i]['end_date'] = $end_date;
	(!$date_action)?date_insert($ex_dates[$i]):'';

	$date_action = true;
	}
	}
	//-------------------------------------------
	}

	if(!$date_action)
	{
	if($selected_dates['status'] == 1)
	{
	date_insert($selected_dates);
	}
	} */
}

function date_delete($product_calendar_id)
{
	tep_db_query("delete from " . TABLE_PRODUCTS_CALENDAR . " where products_calendar_id = '" . (int)$product_calendar_id . "'");
}

function date_insert($sql_data)
{
	if ($sql_data['status'] == 2) $sql_data['price'] = 0;
	if ($sql_data['status']<>2 && $sql_data['start_date']<$sql_data['end_date'])
	tep_db_perform(TABLE_PRODUCTS_CALENDAR, $sql_data);
}

function date_tomorrow($date)
{
	$date = explode('-', $date);
	return date("Y-m-d",mktime(0,0,0,$date[1],$date[2],$date[0]) + 86400);
}

function date_yesterday($date)
{
	$date = explode('-', $date);
	return date("Y-m-d",mktime(0,0,0,$date[1],$date[2],$date[0]) - 86400);
}
?>