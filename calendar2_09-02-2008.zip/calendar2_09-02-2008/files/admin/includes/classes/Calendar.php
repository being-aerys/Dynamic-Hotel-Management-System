<?php

class Calendar
{
  var $Month;
  var $Year;

  function Calendar($month=0,$year=0)
  {
    if ($month==0) $month=date("n");
    if ($year ==0) $year=date("Y");

    $this->Month = $month;
    $this->Year = $year;
  }

  function SetDate($month,$year)
  {
    $this->Month = $month;
    $this->Year = $year;
  }

  function Show()
	{
		global $europeanDate;
		//var_dump($europeanDate);

		if($europeanDate) {
			$weekdayNames	= BK_TEXT_MO.",".BK_TEXT_TU.",".BK_TEXT_WE.",".BK_TEXT_TH.",".BK_TEXT_FR.",".BK_TEXT_SA.",".BK_TEXT_SU;
		} else
			$weekdayNames	= BK_TEXT_SU.','.BK_TEXT_MO.",".BK_TEXT_TU.",".BK_TEXT_WE.",".BK_TEXT_TH.",".BK_TEXT_FR.",".BK_TEXT_SA;
			//$weekdayNames	= "Su,Mo,Tu,We,Th,Fr,Sa";
			
    $month = $this->Month;
    $year = $this->Year;

    $days = date ("d", mktime (0,0,0,$month+1,0,$year));
    $month_name = $this->GetMonthName($month);
    $week_num = 1;

    print "<table border=0 cellpadding=3 cellspacing=1 class=\"cal_bg\">\n";
    print "<tr class=\"cal_header\">\n";
    print "  <td align=center colspan=7>$month_name&nbsp;$year</td>\n</tr>\n";

		print "<tr class=\"cal_header\">\n";

    foreach(split(",",$weekdayNames) as $w) print "  <td align=center>$w</td>\n";
    print "</tr>\n";

		$day_of_week = date ("w", mktime (0,0,0,$month,1,$year));
		if($europeanDate)
			$day_of_week	= ($day_of_week+6)%7;
    //if ($day_of_week == 0) $day_of_week = 7;

    print "<tr>\n";
    for ($i = 1; $i <= $day_of_week; $i++) print "  <td class=\"cal_white\">&nbsp;</td>\n";

    for($day=1; $day <= $days; $day++)
    {
      $info = $this->GetCellInfo($month,$day,$year,false);

      if (isset($info['value'])) $data_value=$info['value'];
      else $data_value = $day;
      
      $attrs = array();
      if (isset($info['attr']) && is_array($info['attr'])) {
        foreach($info['attr'] as $k) {
          foreach($k as $k1=>$v) {
            $attrs[] = "$k1=\"$v\"";
          }
        }
      } else {
        $attrs[]="class=\"cal_unavail\"";
      }
      
      $attr_value=join(" ",$attrs);
      
      print "  <td $attr_value>$data_value</td>\n";
      if ($day_of_week == 6)
      {
        print "</tr>\n<tr>\n";
        $week_num++;
      }
      $day_of_week++; if ($day_of_week==7) $day_of_week=0;
    }
    for ($i = $day_of_week; $i <= 6; $i++) print "  <td class=\"cal_white\">&nbsp;</td>\n";
    print "</tr>\n";

    if ($week_num == 5)
    {
      print "<tr>\n";
      for ($i = 0; $i < 7; $i++) print "  <td class=\"cal_white\">&nbsp;</td>\n";
      print "</tr>\n";
    }

    print "</table>\n";
  }
  
  function GetCellInfo($month,$day,$year) {
    return array();
  }

  function GetMonthName($next_month)
  {
    $months=array(
     BK_TEXT_MNS_01,
     BK_TEXT_MNS_02,
     BK_TEXT_MNS_03,
     BK_TEXT_MNS_04,
     BK_TEXT_MNS_05,
     BK_TEXT_MNS_06,
     BK_TEXT_MNS_07,
     BK_TEXT_MNS_08,
     BK_TEXT_MNS_09,
     BK_TEXT_MNS_10,
     BK_TEXT_MNS_11,
     BK_TEXT_MNS_12
    );

    return $months[$next_month - 1];
  }
}

?>