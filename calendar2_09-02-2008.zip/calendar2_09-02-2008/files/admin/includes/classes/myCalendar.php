<?php

class myCalendar extends Calendar
{
  var $data=array();
  
  function LoadCellInfo($m1,$y1,$m2,$y2, $product_id=false) {
    $date1="$y1-$m1-1"; 
    $days = date ("d", mktime (0,0,0,$m2+1,0,$y2));
    $date2="$y2-$m2-$days";
    if (false !== $product_id)
	{
		$selected_dates=array();

		$sql = "SELECT * FROM products_calendar WHERE product_id = " . $product_id;
		$res = mysql_query($sql);

		$i = 0;
        while($rec = mysql_fetch_array($res)) {
           $selected_dates[$i]['start_date'] = $rec['start_date'];
		   $selected_dates[$i]['end_date'] = $rec['end_date'];
		   $selected_dates[$i]['price'] = $rec['price'];		   
		   $selected_dates[$i]['status'] = $rec['status'];
		   
		   $i++;
        }
	}

    $dates = array();
	$sql="SELECT caldate FROM calendar WHERE caldate between '$date1' and '$date2'";
    $res = mysql_query($sql);
	$i = 0;
    while($rec = mysql_fetch_object($res)) {
		//$dates[$i] = $rec->caldate; 
      $this->data[$rec->caldate] = array('price'=>0,'deposit'=>0,'status'=>2,'products_calendar_id'=>1);
		//$i++;
    }
	    //print "<pre>";
		//print_r($dates);
		//print "</pre>";
    
	for($i = 0; $i < count($selected_dates); $i++)
	{
	   foreach($this->data as $key=>$value)
	   {
	      if(($key >= $selected_dates[$i]['start_date']) AND ($key <= $selected_dates[$i]['end_date']))
		  {
		     $this->data[$key] = array('price'=>$selected_dates[$i]['price'],'deposit'=>$selected_dates[$i]['deposit'],'status'=>$selected_dates[$i]['status'], 'products_calendar_id' => $selected_dates[$i]['products_calendar_id']);
		  }
	   }   
 	}

  }
  function GetTomorrowCellStatus($month,$day,$year) {
    
    $date=date("Y-m-d",mktime(0,0,0,$month,$day,$year) + 86400);
    if (isset($this->data[$date])) {
      $cell = $this->data[$date];
      return $cell['status'];
    }
    return 0;
  }
  function GetYesterdayCellStatus($month,$day,$year) {
    $date=date("Y-m-d",mktime(0,0,0,$month,$day,$year) - 86400);
    if (isset($this->data[$date])) {
      $cell = $this->data[$date];
      return $cell['status'];
    }
    return 0;
  }
  function GetCellInfo($month,$day,$year,$is_admin) {
    $ret=$attr=array();
    
    $date_str=sprintf("%02d/%02d/%d",$month,$day,$year);
    
    $date=sprintf("%d-%02d-%02d",$year,$month,$day);
    //$date_before=sprintf("%d-%02d-%02d",$year,$month,($day-1));
    $date_before=date("Y-m-d",mktime(0,0,0,$month,($day-1),$year));
    //$date_after=sprintf("%d-%02d-%02d",$year,$month,($day+1));
    $date_after=date("Y-m-d",mktime(0,0,0,$month,($day+1),$year));
    //echo $date_before.'<br>';
    
    //echo '<pre>';
    //print_r($this);
    
    
    if (isset($this->data[$date])) {
      $cell = $this->data[$date];
      $cell_before = $this->data[$date_before];
      $cell_after = $this->data[$date_after];

      $price = sprintf("%02d", $cell['price']);

      //no price set
      if ($cell['status']=="" || $cell['status']==0) {
        if (!$is_admin) $attr[]=array('onclick' => "np('$date_str')");
        $attr[]=array('class' => 'cal_noprice');
      }
      
      //available
      /*if ($cell['status']==2) {
      	if (($cell_before['status']==1)) {
      		if ($cell_before['status']==1) $dop_st = '21';
      		if ($cell_after['status']==1) $dop_st = '1';
      		if (($cell_before['status']==1) && ($cell_after['status']==1)) $dop_st = '';
      		$attr[]=array('class' => 'cal_avail_rd'.$dop_st);
        	$color='';
      	}
        elseif ($cell['status']==1) {
        	$attr[]=array('class' => 'cal_avail');
        	$color='green';
        }
      }*/
      
      
      /*if ($cell['status']==1 && ($cell_after['status']==2) ) {
      	 	$attr[]=array('class' => 'cal_avail_rd2');
      	 	//echo '1111111111111';
        	$color='green';
      }
      
      if ($cell['status']==1 && ($cell_before['status']==2) ) {
      	 	$attr[]=array('class' => 'cal_avail_rd1');
      	 	//echo '1111111111111';
        	$color='green';
      } */
      
     if (isset($cell_after))
     if ($cell['status']==2 && ($cell_after['status']==1 || $cell_after['status']==0) ) {
      	 	$attr[]=array('class' => 'cal_avail_rd1');
      	 	//echo '1111111111111';
        	$color='green';
      }
      
      if (isset($cell_before))
      if ($cell['status']==2 && ($cell_before['status']==1 || $cell_before['status']==0) ) {
      	 	$attr[]=array('class' => 'cal_avail_rd2');
      	 	//echo '1111111111111';
        	$color='green';
      }
      
      /*if (($cell['status']==1 && ($cell_before['status']==1)) ||  ($cell['status']==1 && ($cell_after['status']==1) )) {
      	 	$attr[]=array('class' => 'cal_avail');
        	$color='green';
      }*/
      
      if ($cell['status']==1) {
      	 	$attr[]=array('class' => 'cal_avail');
        	$color='green';
      }
      
      /*if ($cell['status']==1) {
      	 	if (($cell_before['status']==2)) {
      	 		$attr[]=array('class' => 'cal_avail_rd1');
      	 	} else {
      	 		if (($cell_after['status']==2)) {
	      	 		$attr[]=array('class' => 'cal_avail_rd2');
  	    	 	} else {
        			$attr[]=array('class' => 'cal_avail');
        			$color='green';
  	    	 	}
      	 	}
      } */

      if ($cell['status']==1 || $is_admin) {
        $attr[]=array('onclick' => "javascript:pd('$month','$day','$year')");
      }
      
      //booked
      if ($cell['status']==2) {
      	
        $attr[]=array('class' => 'cal_booked');
        $color='red';
        
        $stat1 = $this->GetTomorrowCellStatus($month,$day,$year);
        if ($stat1 == 1) {
          $attr[]=array('background'=>'red-green.gif');
          $attr[]=array('onclick' => "javascript:pd('$month','$day','$year')");
        } else {
        
          $stat1 = $this->GetYesterdayCellStatus($month,$day,$year);
          if ($stat1 == 1) {
            $attr[]=array('background'=>'green-red.gif');
            $attr[]=array('onclick' => "javascript:pd('$month','$day','$year')");
          } else
            if (!$is_admin) $attr[]=array('onclick' => "na('$date_str');");
          }
        
        
      }
      
      //unavailable
      if ($cell['status']==3) {
        $attr[]=array('class' => 'cal_unavail');
        if (!$is_admin) $attr[]=array('onclick' => "na('$date_str');");
        $color='red';
      }
      
      if ($cell['price']>0) {
        $attr[]=array('onmouseover' => "sp('$price','navy')");
        $attr[]=array('onmouseout' => "sp('')");
      }
      
      
      $ret['attr']=$attr;
      $ret['value']=$day;
      $ret['status']=$cell['status'];
      
      return $ret;
    }

    return $ret;
  }
}

?>