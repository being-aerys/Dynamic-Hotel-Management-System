<?php
/*
  $Id: header_navigation.php,v 1.19 2003/04/27 16:11:52 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Updated by Gnidhal (fx@geniehalles.com)
*/
  $menu_dhtml = MENU_DHTML;
  $box_files_list = array();

function CanShowBox($dop = '') {
	return true;
}  
  
//rmh M-S_multi-stores begin
  if (CanShowBox('configuration.php')) { 
		$box_files_list[] = array("configuration", "configuration.php" , BOX_HEADING_CONFIGURATION);
  }
  if (CanShowBox('modules.php')) {  
		$box_files_list[] = array("modules", "modules.php" , BOX_HEADING_MODULES);
  }
  if (CanShowBox('catalog.php')) {  
		$box_files_list[] = array("catalog", "catalog.php" , BOX_HEADING_CATALOG);
  }
  if (CanShowBox('customers.php')) {  
		$box_files_list[] = array("customers", "customers.php" , BOX_HEADING_CUSTOMERS);
  }
 // if (CanShowBox('taxes.php')) {  
	//	$box_files_list[] = array("taxes", "taxes.php" , BOX_HEADING_LOCATION_AND_TAXES);
//  }
  if (CanShowBox('localization.php')) {  
		$box_files_list[] = array("localization", "localization.php" , BOX_HEADING_LOCALIZATION);
  }
  if (CanShowBox('reports.php')) {  
		$box_files_list[] = array("reports", "reports.php" , BOX_HEADING_REPORTS);
  }
  if (CanShowBox('tools.php')) {  
		$box_files_list[] = array("tools", "tools.php" , BOX_HEADING_TOOLS);
  }
if (CanShowBox('administrator.php')) {  
		$box_files_list[] = array("administrator", "administrator.php" , BOX_HEADING_ADMINISTRATOR);
  }
   echo '<!-- Menu bar #2. --> <div class="menuBar" style="width:100%;">';
   
   foreach($box_files_list as $item_menu) {
     echo "<a class=\"menuButton\" href=\"\" onclick=\"return buttonClick(event, '".$item_menu[0]."Menu');\" onmouseover=\"buttonMouseover(event, '".$item_menu[0]."Menu');\">".$item_menu[2]."</a>" ;
   }
   echo "</div>";
foreach($box_files_list as $item_menu) require(DIR_WS_BOXES. $item_menu[1] );


?>