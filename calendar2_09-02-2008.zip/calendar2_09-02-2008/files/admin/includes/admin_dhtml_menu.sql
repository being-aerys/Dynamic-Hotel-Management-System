INSERT INTO `configuration` ( `configuration_id` , `configuration_title` , `configuration_key` , `configuration_value` , `configuration_description` , `configuration_group_id` , `sort_order` , `last_modified` , `date_added` , `use_function` , `set_function` )
VALUES (
'', 'Admin DHTML Menus', 'MENU_DHTML', 'true', 'Shows the DHTML menu instead of the default menu.', '1', '19', NULL , '0000-00-00 00:00:00', NULL , 'tep_cfg_select_option(array(''true'', ''false''),'
);