<?php
/*
  $Id: header.php,v 1.19 2002/04/13 16:11:52 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  if ($messageStack->size > 0) {
    echo $messageStack->output();
  }
?>
<script language="javascript" src="includes/menu.js"></script>
<?php if (MENU_DHTML == 'true') echo '<link rel="stylesheet" type="text/css" href="includes/menu.css">'; ?>
<?php if (MENU_DHTML == 'true') require(DIR_WS_INCLUDES . 'header_navigation.php'); ?>
<!-- BOE Access with Level Account (v. 2.2a) for the Admin Area of osCommerce (MS2) 1 of 1 -->
<!-- reverse comments to below lines to disable this contribution -->
<table bgcolor="#999999">
    <td bgcolor="#999999">&nbsp;&nbsp;<?php
		if (tep_session_is_registered('login_id')) {
    echo '<a href="' . tep_href_link(FILENAME_ADMIN_ACCOUNT, '', 'SSL') . '" class="headerLink">' . HEADER_TITLE_ACCOUNT . '</a> | <a href="' . tep_href_link(FILENAME_LOGOFF, '', 'NONSSL') . '" class="headerLink">' . HEADER_TITLE_LOGOFF . '</a>';
  } else {
    echo '<a href="' . tep_href_link(FILENAME_DEFAULT, '', 'NONSSL') . '" class="headerLink">' . HEADER_TITLE_TOP . '</a>';
  }
	?></td></table>
<!-- BOE Access with Level Account (v. 2.2a) for the Admin Area of osCommerce (MS2) 1 of 1 -->