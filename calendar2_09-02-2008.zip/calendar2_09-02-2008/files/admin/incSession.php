<?php
// Include application configuration parameters
  require('includes/configure.php');

// Check for a cookie, if none got to login page
if(!isset($HTTP_COOKIE_VARS['session_id'])) {
header('Location: ' . HTTPS_CATALOG_SERVER . DIR_WS_ADMIN . 'login.php?refer=' . urlencode($PHP_SELF . '?' . $HTTP_SERVER_VARS['QUERY_STRING']));
}
// Try to find a match in the database
$sGUID = $HTTP_COOKIE_VARS['session_id'];
$sQuery = "SELECT ID FROM administrator WHERE sGUID = '$sGUID'";
$hResult = mysql_query($sQuery);
if(!mysql_affected_rows()) { // No match for guid, return to login
header('Location: ' . HTTPS_CATALOG_SERVER . DIR_WS_ADMIN . 'login.php?refer=' . urlencode($PHP_SELF . '?' . $HTTP_SERVER_VARS['QUERY_STRING']));
}
?>